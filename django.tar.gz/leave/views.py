# views.py

from django.utils import timezone
from django.core.paginator import Paginator

from rest_framework import status
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework_simplejwt.tokens import RefreshToken

from .models import Leave
from .serializers import (
    LeaveSerializer,
    UserRegisterSerializer,
    UserProfileSerializer,
    ChangePasswordSerializer
)
from .decorators import group_required


# 学生注册
@permission_classes([AllowAny])
class RegisterView(APIView):
    def post(self, request):
        serializer = UserRegisterSerializer(data=request.data)
        if serializer.is_valid():
            user = serializer.save()
            refresh = RefreshToken.for_user(user)
            return Response({
                'detail': 'User registered successfully!',
                'refresh': str(refresh),
                'access': str(refresh.access_token),
            }, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# 学生提交请假申请
@api_view(['POST'])
@permission_classes([IsAuthenticated])
def request_leave(request):
    data = request.data.copy()
    data['leave_time'] = timezone.now()
    serializer = LeaveSerializer(data=data, context={'request': request})
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# 管理员/教师/mas 查看请假条（分页 + 按 status 过滤）
@api_view(['GET'])
@permission_classes([IsAuthenticated])
@group_required('admin', 'tch', 'mas')
def AdminLeaveListView(request):
    user = request.user
    status_param = request.query_params.get('status')
    page_num = int(request.query_params.get('page', 1))
    page_size = int(request.query_params.get('page_size', 10))

    # 根据角色决定查询范围
    if user.groups.filter(name__in=['admin', 'mas']).exists():
        qs = Leave.objects.all()
    else:
        # tch 组只能看自己学生
        students = user.students.all().values_list('user', flat=True)
        qs = Leave.objects.filter(student__in=students)

    # 按状态过滤
    if status_param is not None:
        qs = qs.filter(status=status_param)

    qs = qs.order_by('-leave_time')

    # 分页
    paginator = Paginator(qs, page_size)
    page_obj = paginator.get_page(page_num)
    serializer = LeaveSerializer(page_obj.object_list, many=True)

    return Response({
        'count': paginator.count,
        'next': page_obj.next_page_number() if page_obj.has_next() else None,
        'previous': page_obj.previous_page_number() if page_obj.has_previous() else None,
        'results': serializer.data,
    })


# 学生查询自己请假条（分页 + 按 status 可选）
@api_view(['GET'])
@permission_classes([IsAuthenticated])
@group_required('stu')
def get_student_leaves(request):
    status_param = request.query_params.get('status')
    page_num = int(request.query_params.get('page', 1))
    page_size = int(request.query_params.get('page_size', 10))

    qs = Leave.objects.filter(student=request.user)
    if status_param is not None:
        qs = qs.filter(status=status_param)
    qs = qs.order_by('-leave_time')

    paginator = Paginator(qs, page_size)
    page_obj = paginator.get_page(page_num)
    serializer = LeaveSerializer(page_obj.object_list, many=True)

    return Response({
        'count': paginator.count,
        'next': page_obj.next_page_number() if page_obj.has_next() else None,
        'previous': page_obj.previous_page_number() if page_obj.has_previous() else None,
        'results': serializer.data,
    })


# 管理员批准请假
@api_view(['PATCH'])
@permission_classes([IsAuthenticated])
@group_required('admin', 'tch', 'mas')
def approve_leave(request, leave_id):
    try:
        leave = Leave.objects.get(id=leave_id)
    except Leave.DoesNotExist:
        return Response({'error': 'Leave not found'}, status=status.HTTP_404_NOT_FOUND)
    leave.status = 1
    leave.approver = request.user.last_name
    leave.save()
    return Response({'status': 'Leave approved'})


# tch 初审批准请假
@api_view(['PATCH'])
@permission_classes([IsAuthenticated])
@group_required('admin', 'tch')
def pre_approve_leave(request, leave_id):
    try:
        leave = Leave.objects.get(id=leave_id)
    except Leave.DoesNotExist:
        return Response({'error': 'Leave not found'}, status=status.HTTP_404_NOT_FOUND)
    leave.status = 5
    leave.approver = request.user.last_name
    leave.save()
    return Response({'status': 'Leave pre-approved'})


# mas 批准长假期
@api_view(['PATCH'])
@permission_classes([IsAuthenticated])
@group_required('admin', 'tch')
def mas_approve_leave(request, leave_id):
    try:
        leave = Leave.objects.get(id=leave_id)
    except Leave.DoesNotExist:
        return Response({'error': 'Leave not found'}, status=status.HTTP_404_NOT_FOUND)
    leave.status = 1
    leave.approver = request.user.last_name
    leave.save()
    return Response({'status': 'Long leave approved'})


# 管理员拒绝请假
@api_view(['POST'])
@permission_classes([IsAuthenticated])
@group_required('admin', 'tch', 'mas')
def reject_leave(request, leave_id):
    try:
        leave = Leave.objects.get(id=leave_id)
    except Leave.DoesNotExist:
        return Response({'error': 'Leave not found'}, status=status.HTTP_404_NOT_FOUND)

    reject_reason = request.data.get('reject_reason')
    if reject_reason:
        leave.reject_reason = reject_reason

    if leave.status in [0, 4]:
        leave.status = 2
        leave.approver = request.user.last_name
        leave.save()
        return Response({'status': 'Leave rejected'})
    return Response({'error': 'Only pending leaves can be rejected'}, status=status.HTTP_400_BAD_REQUEST)


# 管理员/tch 销假
@api_view(['PATCH'])
@permission_classes([IsAuthenticated])
@group_required('admin', 'tch')
def complete_leaving(request, leave_id):
    try:
        leave = Leave.objects.get(id=leave_id)
    except Leave.DoesNotExist:
        return Response({'error': 'Leave not found'}, status=status.HTTP_404_NOT_FOUND)
    if leave.status == 1:
        leave.status = 3
        leave.save()
        return Response({'status': 'Leave completed'})
    return Response({'error': 'Only approved leaves can be completed'}, status=status.HTTP_400_BAD_REQUEST)


# 学生取消请假
@api_view(['PATCH'])
@permission_classes([IsAuthenticated])
def cancel_leave(request, leave_id):
    try:
        leave = Leave.objects.get(id=leave_id, student=request.user)
    except Leave.DoesNotExist:
        return Response({'error': 'Not found or no permission'}, status=status.HTTP_404_NOT_FOUND)
    if leave.status != 0:
        return Response({'error': 'Only pending leaves can be canceled'}, status=status.HTTP_400_BAD_REQUEST)
    leave.status = -1
    leave.save()
    return Response({'message': 'Leave canceled'}, status=status.HTTP_200_OK)


# 用户查询自己信息
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def UserInfoView(request):
    serializer = UserProfileSerializer(request.user)
    return Response(serializer.data, status=status.HTTP_200_OK)


# 修改密码
class ChangePasswordView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request, *args, **kwargs):
        serializer = ChangePasswordSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            serializer.save()
            return Response({"detail": "Password updated successfully."}, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
