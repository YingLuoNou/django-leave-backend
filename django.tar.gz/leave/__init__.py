# leave/__init__.py

default_app_config = 'leave.apps.LeaveConfig'
